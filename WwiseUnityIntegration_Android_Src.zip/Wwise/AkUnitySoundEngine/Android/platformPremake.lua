-- Android Unity premake module
local platform = {}

function platform.setupTargetAndLibDir(baseTargetDir)
    libdirs("$ENV{WWISESDK}/Android_%cfg.platform%/%{cfg.buildcfg}/lib")
    targetdir(baseTargetDir .. "Android/%{cfg.platform}/%{cfg.buildcfg}")
end

function platform.platformSpecificConfiguration()
    files
    {
        "../Android/AkFileHelpers.cpp",
    }

    excludes
    {
        "../Common/AkMultipleFileLocation.cpp",
    }

    includedirs
    {
        "$ENV{WWISESDK}/samples/SoundEngine/Android/libzip/lib",
    }

    links
    {
        "OpenSLES",
        "android",
        "log",
        "dl",
        "zip",
        "z"
    }

    linkoptions
	{
        "-Wl,--as-needed"
	}

end

return platform